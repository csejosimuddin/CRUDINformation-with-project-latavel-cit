
যেখানে ইমেজগুলো দেখাবে সেখানে
<img src="{{ asset('uploads/product_photos') }}/{{ $all_Product->Product_image }}">


@foreach($related_product as $related_product)

$all_Product এটা পরিবতে $related_product হবে বুঝেছো
Single Pageএ হলে single page এ @foreach এর মধে যা থাকবে তাই দিয়ে ধরতে হবে