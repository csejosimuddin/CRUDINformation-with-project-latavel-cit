<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use Image;এটা config এর মধে আসছে

class ProductController extends Controller
{


    function addproductinsert(Request $request){
		// Form-Validation
		$request->validate([
			'Product_Name_josim' => 'required',
			'Product_Description' => 'required',
			'Product_Price' => 'required|numeric',
			'Product_Quentity' => 'required|numeric',
			'Product_Alert_Quentity' => 'required|numeric',
		]);

// ইমেজ যোগ করা জনে $last_inserted_id = Product::insertGetId এটা দিতে হবে

    	$last_inserted_id = Product::insertGetId([
   // Product_Name এটা টেবিলের কলামের নাম
// $request->Product_Name_josim, এটা টেবিলের input এর name="Product_Name_josim" থেকে আসছে
    		'Product_Name' => $request->Product_Name_josim,
    		'Product_Description' => $request->Product_Description,
    		'Product_Price' => $request->Product_Price,
    		'Product_Quentity' => $request->Product_Quentity,
    		'Product_Alert_Quentity' => $request->Product_Alert_Quentity,
    	]);

       // ছবি আপলোডের জনে
    	// Image এটা আসছে Config থেকে
    	// Product_image এটা ফরমের ভিতরের input name

    	if($request->hasFile('Product_image')){
    		$photo_to_upload = $request->Product_image;
    		$filename = $last_inserted_id.".".$photo_to_upload->getClientOriginalExtension();
    		Image::make($photo_to_upload)->resize(400,450)->save(base_path('public/uploads/product_photos/'.$filename),85);
    		Product::find($last_inserted_id)->update([
    			'Product_image' => $filename
    		]);

    		// 85 এটা ইমেজের MB টাকে ছোট করে দেই
    	}

    	return back()->with('status', 'Product Insert SuccessFully!');
    	// ডাটা Insert হলে SuccessFully message দেওয়ার জনে এবং যেখানে message
    	// দেখাবো মানে form এর মধে ও কিছু কাজ আছে

    	// এই মেথডের রাউট Route::post('/add/product/insert','ProductController@addproductinsert');
    }







}