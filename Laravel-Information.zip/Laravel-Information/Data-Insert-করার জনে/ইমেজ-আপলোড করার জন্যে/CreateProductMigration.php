  
<!-- $table->string('Product_image')->default('defaultproductphoto.jpg');
এটা নতুন করে যোগ করা 
php artisan migration:rollback করে আবার migration করতে হবে -->

  public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('Product_Name');
            $table->longText('Product_Description');
            $table->integer('Product_Price');
            $table->integer('Product_Quentity');
            $table->integer('Product_Alert_Quentity');
            $table->string('Product_image')->default('defaultproductphoto.jpg');
            $table->timestamps();
            $table->softDeletes();
        });
    }