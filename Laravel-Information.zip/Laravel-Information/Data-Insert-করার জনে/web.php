// Product Route
Route::get('/Add/Product/View','ProductController@index');

Route::post('/add/product/insert','ProductController@addproductinsert');