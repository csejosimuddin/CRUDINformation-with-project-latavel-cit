<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;

class ProductController extends Controller
{
    // ডাটাবেস থেকে ডাটা দেখানোর জনে
     function index(){
        $all_Products = Product::orderBy('id','desc')->paginate(2);
        // ->paginate(2) পেজিনেশন দেওয়ার জনে এবং front এ ও কিছু লিখতে হিবে
        return view('Product.AddNewProduct',compact('all_Products'));
    }
    

    // ডাটাবেসে নতুন ডাটা যোগ করার জনে

    function addproductinsert(Request $request){

                // Form-Validation
        // Product_Name_josim এগুলা ফরমের টেবিলের name=" যা আছে তাই হবে এখানে " টেবিলের কলামের নাম না
        $request->validate([
            'Product_Name_josim' => 'required',
            'Product_Description' => 'required',
            'Product_Price' => 'required|numeric',
            'Product_Quentity' => 'required|numeric',
            'Product_Alert_Quentity' => 'required|numeric',
        ]);

    	Product::insert([
   // Product_Name এটা টেবিলের কলামের নাম
// $request->Product_Name_josim, এটা টেবিলের input এর name="Product_Name_josim" থেকে আসছে
    		'Product_Name' => $request->Product_Name_josim,
    		'Product_Description' => $request->Product_Description,
    		'Product_Price' => $request->Product_Price,
    		'Product_Quentity' => $request->Product_Quentity,
    		'Product_Alert_Quentity' => $request->Product_Alert_Quentity,
    	]);

    	return back()->with('status', 'Product Insert SuccessFully!');
    	// ডাটা Insert হলে SuccessFully message দেওয়ার জনে এবং যেখানে message
    	// দেখাবো মানে form এর মধে ও কিছু কাজ আছে

    	// এই মেথডের রাউট Route::post('/add/product/insert','ProductController@addproductinsert');
    }



}
