@extends('layouts.app')
@section('content')
<div class="container">
   <div class="row">
      <div class="col-lg-4">
         <div class="card px-3 py-3">
            <div class="card-header bg-success">
               Add Product Form
            </div>

            <!-- এর মাধমে success alert টা পাবো -->
            @if(session('status')) 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-success">
               {{ session('status') }}
            </div>
            @endif

            <!-- ফরম validation এর পরে Error দেখানোর জনে
            $errors এটা laravel এর builtin function -->
            @if($errors->all())
            <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
             @endforeach
            </div>
            @endif

            <form action="{{ url('/add/product/insert') }}" method="post">
               <!--  {{ url('/add/product/insert') }} এটা Route থেকে আসছে -->
               <!-- ফরমের ডাটা ডাটাবেসে পাঠাইতে হলে @csrf লিখতেই হবে  -->

               @csrf


               <div class="form-group">
                  <label>Product Name</label>
                  <input type="text" class="form-control" name="Product_Name_josim" placeholder="Enter Product Name">
               </div>
               <div class="form-group">
                  <label>Product Description</label>
                  <textarea class="form-control" name="Product_Description" rows="3" placeholder="Enter Product Description"></textarea>
               </div>
               <div class="form-group">
                  <label>Product Price</label>
                  <input type="text" class="form-control" name="Product_Price" placeholder="Enter Product Price">
               </div>
               <div class="form-group">
                  <label>Product Quentity</label>
                  <input type="text" class="form-control" name="Product_Quentity" placeholder="Enter Product Quentity">
               </div>
               <div class="form-group">
                  <label>Product Alert Quentity</label>
                  <input type="text" class="form-control" name="Product_Alert_Quentity" placeholder="Enter Product Alert Quentity">
               </div>
               <button type="submit" class="btn btn-info">Submit</button>
            </form>
         </div>
      </div>






      
      <div class="col-lg-8">
         <table class="table table-bordered">
            <thead>
               <tr>
                  <th>SL.NO</th>
                  <th>Product_Name</th>
                  <th>Product_Description</th>
                  <th>Product_Price</th>
                  <th>Product_Quentity</th>
                  <th>Product_Alert_Quentity</th>
               </tr>
            </thead>
            <tbody>
               <!-- এর মাধমে ডাটাবেস থেকে ডাটাগুলো দেখাছে -->
               @foreach( $all_Products as $all_Product )
               <tr>
                  <!-- $loop->index+1 এর মাধমে SL.NO দেখাবে এটা laravel এর Builtin function -->
                  <td>{{ $loop->index+1 }}</td>
                  <td>{{ $all_Product->Product_Name }}</td>
                  <td>{{ $all_Product->Product_Description }}</td>
                  <td>{{ $all_Product->Product_Price }}</td>
                  <td>{{ $all_Product->Product_Quentity }}</td>
                  <td>{{ $all_Product->Product_Alert_Quentity }}</td>
               </tr>
               @endforeach
            </tbody>
         </table>

         <!-- পেজিনেশন দেওয়ার জনে এর জনে
          Controller এ  $all_Products = Product::orderBy('id','desc')->paginate(2);
          ->paginate(2); এটা আছে -->
            {{ $all_Products->links() }}

      </div>
   </div>
</div>
@endsection