<ul class="navbar-nav mr-auto">
		 <li class="nav-item">
		   <a class="nav-link" href="{{ url('/Add/Product/View') }}d">Add New Prouct</a>
		 </li>
 </ul>