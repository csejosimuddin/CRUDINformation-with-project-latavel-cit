






  <thead>
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Created At</th>
      <th>Updated At</th>
    </tr>
  </thead>
  <tbody>

  <!-- আমার যেহেতু tr এর মধে ডাটাগুলো বসবে তাই tr কে @foreach loop এর মাধমে ঘুরাব 
$all_users এটা Controller এর compact থেকে আসছে
name,email,created_at,updated_at এগুলা যে টেবিলের ডাটাগুলো দেখাতে চাছি সেই টেবিলের কলামের নাম -->
  
	@foreach($all_users as $user)
    <tr>
      <td>{{ $user->name }}</td>
      <td>{{ $user->email }}</td>
      <td>{{ $user->created_at }}</td>
      <td>{{ $user->updated_at }}</td>
    </tr>
 @endforeach
  
  </tbody>
</table>