যে পেজের মধে ডাটাকে দেখাব তার তো একটি View থাকে সেই View এর মধে ডাটাকে কল করতে হবে
*****
**** COntroller এর উপরে use App\User; যুকত করতে হবে  User এটা মডেলের নাম


public function index(){
	$all_users = User::all(); /*User হছে মডেলের নাম/*
	return view('home', compact('all_users'));
}

home পেজে ডাটাগুলো যাতে দেখায় তার জনে compact('all_users') এই বিষয়টা যুকত করতে হবে মানে home পেজ লোড নেওয়ার পরে ডাটাগুলো দেখাবে