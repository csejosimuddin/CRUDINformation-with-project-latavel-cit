

	// ডাটা ডিলিট করার জন্যে

	function deleteproduct($product_id){
		Product::where('id', $product_id)->delete();
		return back()->with('deletestatus', 'Product Delete SuccessFully!');
	}


	
 এবং রাউট হবে
 // Delete Route
Route::get('/delete/product/{product_id}','ProductController@deleteproduct');

<!-- {product_id} এটা যে কোন নাম হতে পারে -->