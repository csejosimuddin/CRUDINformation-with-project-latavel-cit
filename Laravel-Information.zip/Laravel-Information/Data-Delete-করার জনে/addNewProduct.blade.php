  <div class="col-lg-8">
                  <!-- এর মাধমে success alert টা পাবো -->
                  @if(session('deletestatus')) 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-danger">
               {{ session('deletestatus') }}
            </div>
            @endif
            
         <table class="table table-bordered">
            <thead>
               <tr>
                  <th>Product_Name</th>
                  <th>Product_Description</th>
                  <th>Product_Price</th>
                  <th>Product_Quentity</th>
                  <th>Product_Alert_Quentity</th>
                  <th>Action</th>
               </tr>
            </thead>
            <tbody>
               <!-- এর মাধমে ডাটাবেস থেকে ডাটাগুলো দেখাছে -->
               @forelse( $all_Products as $all_Product )
               <tr>
                  <td>{{ $all_Product->Product_Name }}</td>
                  <td>{{ $all_Product->Product_Description }}</td>
                  <td>{{ $all_Product->Product_Price }}</td>
                  <td>{{ $all_Product->Product_Quentity }}</td>
                  <td>{{ $all_Product->Product_Alert_Quentity }}</td>
                  <td>

                     <!-- ডিলিটের জনে {{ url('/delete/product') }}/{{ $all_Product->id }} এটা রাউট থেকে আসছে -->
                  <a href="{{ url('/delete/product') }}/{{ $all_Product->id }}" class="btn btn-sm btn-danger">
                  Delete</a>
                  </td>
               </tr>
               @empty
               <tr class="text-center">
               <td colspan="6"> No Data Available</td>
               
               </tr>
               @endforelse
            </tbody>
         </table>

         <!-- পেজিনেশন দেওয়ার জনে এর জনে
          Controller এ  $all_Products = Product::orderBy('id','desc')->paginate(2);
          ->paginate(2); এটা আছে -->
            {{ $all_Products->links() }}

      </div>