// Edit করে ডাটা যুকত করার জনে
product_id এটা productedit.blade.php থেকে আসছে

function editproductinsert(Request $request){
	Product::find($request->product_id)->update([
		'Product_Name' => $request->Product_Name_josim,
		'Product_Description' => $request->Product_Description,
		'Product_Price' => $request->Product_Price,
		'Product_Quentity' => $request->Product_Quentity,
		'Product_Alert_Quentity' => $request->Product_Alert_Quentity,

	]);
	return back()->with('updatestatus', 'Product Update SuccessFully!');
}




// Edit করে ডাটা যুকত করার জনে
Route::post('/edit/product/insert','ProductController@editproductinsert');


//এবং মডেলে কিছু লিখতে হবে 

protected $fillable = ['Product_Name','Product_Description','Product_Price','Product_Quentity','Product_Alert_Quentity'];

Product_Nameএগুলা টেবিলের কলামের নাম