এখানে পরিবতন
1.   <input type="hidden" class="form-control" name="product_id" placeholder="Enter Product Name" value="{{ $single_product_info-> id }}">

$single_product_info এটা Controller এবং id এটা টেবিলের কলাম

2. <form action="{{ url('/edit/product/insert') }}" method="post"> 
   {{ url('/edit/product/insert') }} এটা Route থেকে আসছে








@extends('layouts.app')
@section('content')

<div class="container">
   <div class="row">
      <div class="col-lg-6 offset-3">


    <!-- BreadCome দেওয়ার জনে -->
    <nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="{{ url('/home') }}">Dashbord</a></li>
    <li class="breadcrumb-item"><a href="{{ url('/Add/Product/View') }}">Product List</a></li>
    <li class="breadcrumb-item active" aria-current="page"> {{ $single_product_info-> Product_Name }} </li>
  </ol>
</nav>
<!-- {{ $single_product_info-> Product_Name }} এটা ফরম থেকে আসছে যাকে ইডিট করব তার নামটা breadcome এ দেখাবে তাই দেওয়া -->


         <div class="card px-3 py-3">
            <div class="card-header bg-success">
               Edit Product Form
               <!-- {{ $single_product_info }} -->
            </div>
            <!-- এর মাধমে success alert টা পাবো -->
            @if(session('updatestatus')) 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-success">
               {{ session('updatestatus') }}
            </div>
            @endif
            <form action="{{ url('/edit/product/insert') }}" method="post">
               <!--  {{ url('/add/product/insert') }} এটা Route থেকে আসছে -->
               <!-- ফরমের ডাটা ডাটাবেসে পাঠাইতে হলে @csrf লিখতেই হবে  -->
               @csrf
               <div class="form-group">
                  <label>Product Name</label>
                  <!-- Product এর ID টাকে ধরে আপডেট করার জনে এই input file টা লিখতে হবে -->

                  <input type="hidden" class="form-control" name="product_id" placeholder="Enter Product Name" value="{{ $single_product_info-> id }}">
                  <input type="text" class="form-control" name="Product_Name_josim" placeholder="Enter Product Name" value="{{ $single_product_info-> Product_Name }}">
               </div>
               <div class="form-group">
                  <label>Product Description</label>
                  <textarea class="form-control" name="Product_Description" rows="3" placeholder="Enter Product Description">{{ $single_product_info-> Product_Description }}</textarea>
               </div>
               <div class="form-group">
                  <label>Product Price</label>
                  <input type="text" class="form-control" name="Product_Price" placeholder="Enter Product Price" value="{{ $single_product_info-> Product_Price }}">
               </div>
               <div class="form-group">
                  <label>Product Quentity</label>
                  <input type="text" class="form-control" name="Product_Quentity" placeholder="Enter Product Quentity" value="{{ $single_product_info-> Product_Quentity }}">
               </div>
               <div class="form-group">
                  <label>Product Alert Quentity</label>
                  <input type="text" class="form-control" name="Product_Alert_Quentity" placeholder="Enter Product Alert Quentity" value="{{ $single_product_info->	Product_Alert_Quentity }}">
               </div>
               <button type="submit" class="btn btn-success">Update</button>
            </form>
         </div>
      </div>
      </div>
      </div>


@endsection