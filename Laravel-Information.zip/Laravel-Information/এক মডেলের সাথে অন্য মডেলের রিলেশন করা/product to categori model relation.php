**** 
1.Product model এর মধে category model এর ডাটাকে দেখানোর জনে মডেলের সাথে রিলেশন করাতে হবে 

2. যেহেতু product model এর মধে Category model এর ডাটা কে দেখাবো তাই product model এর model এর মধে

function relationtocategory(){
	return $this->hasOne('App\category', 'id', 'category_id');
}

1. 'App\category' এর category Model name,

2. 'id' এটা category table এর primery id,

3. 'category_id' এটা product table এ category id টা দেখায় 

আউটপুট দেখানোর জনে
@forelse($products as $product)
<tr>
	<td>{{ $product->relationtocategory->category_name }}</td>
</tr>
category_name এটা হছে category table এর colom এর নাম


=======================================================================

Single product click করলে যখন product details এ যায় তখন তার নিচে যে Related product দেখায় সেখানে যে category এর product view করেছি সেই category এর Related product দেখাবে

function productdetails($product_id){
	$single_product_info = product::find($product_id);
	$related_products = product::where('id', '!=', $product_id)->where('category_id', $single_product_info->category_id)->get();

	return view('frontend/productdetails', compact('single_product_info','related_products'));

}

এখানে ->where('category_id', $single_product_info->category_id) নতুন 