	// ডিলিট করা ডাটাগুলে Permantly Delete করার জনে
function permantlyDeleteProduct($product_id){

// আপলোড করা ছবি গুলো একেবারে ডিলিট করার জনে
$delete_this_file = Product::onlyTrashed()->find($product_id)->Product_image;
unlink(base_path('public/uploads/product_photos/'.$delete_this_file));


	Product::onlyTrashed()->find($product_id)->forceDelete();
	return back();
}