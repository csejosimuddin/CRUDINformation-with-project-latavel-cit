<a href="{{ url('category/wise/product') }}/{{ $category->id }}"></a>


Route a


Route::get('category/wise/product/{category_id}','ProductController@categorywiseproduct');


<!-- Controller এর মধে -->
function categorywiseproduct($category_id){
	
	$products = product::where('category_id', $category_id)->get();
	return view('frontend/categorywiseproduct',compact('products'));
}