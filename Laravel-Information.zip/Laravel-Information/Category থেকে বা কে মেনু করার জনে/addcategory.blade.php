
<div class="form-group">
	<input type="checkbox" name="menu_status" value="1" id="menu">
	<label for="menu">Use as Menu</label>	
</div>


<!-- Menu status Dashbord এ দখানোর জনে -->

<div class="col-lg-8">

         <table class="table table-bordered">
            <thead>
               <tr>
                  <th>SL.NO</th>
                  <th>Category Name</th>
                  <th>Menu Status</th>
               </tr>
            </thead>
            <tbody>
               <!-- এর মাধমে ডাটাবেস থেকে ডাটাগুলো দেখাছে -->
               @forelse($categories as $category)
               <tr>
               
                  <td>{{ $category->category_id }}</td>
             
                  <td>{{ $category->created_at }}</td>
                  <td>{{ ($category->menu_status == 1) ? "YES":"NO" }}</td>
               
<!-- {{ ($category->menu_status == 1) ? "YES":"NO" }} shortcut if else condition -->

      
               </tr>
               @empty

               <tr class="text-center">
                  <td colspan="6"> No Data Available</td>
               </tr>
               @endforelse
            </tbody>
         </table>

      </div>