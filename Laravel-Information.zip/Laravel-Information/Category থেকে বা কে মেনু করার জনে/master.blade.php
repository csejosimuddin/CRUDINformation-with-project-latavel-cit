









<!-- Controller ছাড়া ডাইরেক্ট blade.php তে controller কে যুকত করে foreach loop 
চালানোর জনে 
এখানে category থেকে মেনু ডাইনামকলি নিয়ে আসব -->

<ul class="main-menu">
@php
$jkononame = App\categories::where('menu_status', 1)->get();
@endphp

<li><a href="{{ url('/') }}">Home</a></li>
@foreach($jkononame as $menu)
<li><a href="{{ url('category/wise/product') }}/{{ $menu->id }}">{{ $menu->category_id }}</a></li>
@endforeach
<!-- category_id এটা categories টেবিলের কলামের নাম -->

<li><a href="{{ url('/home') }}">Dashbord</a></li>
</ul>
</div>