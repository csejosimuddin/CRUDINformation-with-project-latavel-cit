
*** <!-- Database এ categories টেবিলে একটি কলাম করব menu_status নামে 
যার টাইপ Boolean হবে Boolean মানে true or false 0 or 1 -->

  function addcategoryinsert(Request $request){
    // Form-Validation
    $request->validate([
        'category_name' => 'required|unique:categories,category_id'
    
    ]);

    // categories যোগ করার জনে	
    <!-- category কে মেনু করার জনে -->
    if(isset($request->menu_status)){

      categories::insert([
        'category_id' => $request->category_name,
        'menu_status' => true,
        'created_at' => Carbon::now()
    ]);

}

else{
	
	      categories::insert([
        'category_id' => $request->category_name,
        'menu_status' => false,
        'created_at' => Carbon::now()
    ]);


}
    



    return back()->with('status', 'Product Insert SuccessFully!');
}



<!-- manu কে Controll করার জনে Controller এ -->

function changemenustatus($category_id){
    if(category::find($category_id)->menu_status == 0){
    category::find($category_id)->update([
    'menu_status' => true

    ]);
}

else{
     category::find($category_id)->update([
    'menu_status' => false
    ]);
}
return back();
}


উপরের কোডটাই আরেক ভাবে আপডেট করা যায়
$category_info = category::find($category_id);
if($category_info->menu_status == 0){
    $category_info->menu_status = true;
}
else{
    $category_info->menu_status = false;
}
$category_info->save();

return back();