 
 Route::get('add/category/view', 'CategoryController@addcategoryview');

 Route::post('add/category/insert', 'CategoryController@addcategoryinsert');

======================================================================
use App\Category; 
use Carbon\Carbon;



 function addcategoryview(){
 $categories = Category::all();
 return view('category.view', compact('categories'));

}


function addcategoryinsert(Request $request){
	$request->validate([
	'category_name' => 'required|unique:categories,category_name'
	]);

	<!-- categories টেবিলের নাম, ফরমের মধের name="category_name" -->

Category::insert([
'category_name' => $request->category_name,
'created_at' => Carbon::now()
<!-- এটা দিলে config>app.php> 'timezone' => 'UTC',UTC এর এখানে Asia/Dhaka বসায় দিলেই হবে  -->
'created_at' => Carbon::now('Asia/Dhaka')
<!--  এটা নতুন এর মাধমে নতুন ডাটা যুকত করার সময় টা দেখাবে -->
]);

}