

1.
<ul class="main-menu">
@php
$jkononame = App\categories::latest()->take(2)->get();
@endphp

<li><a href="{{ url('/') }}">Home</a></li>
@foreach($jkononame as $menu)
<li><a href="{{ url('category/wise/product') }}/{{ $menu->id }}">{{ $menu->category_id }}</a></li>
@endforeach
<!-- category_id এটা categories টেবিলের কলামের নাম -->

<li><a href="{{ url('/home') }}">Dashbord</a></li>
</ul>














link
<a href="{{ category/wise/product }}/{{ $categories->id }}"></a>

Route
Route::get('category/wise/product/{category_id}','ProductController@categorywiseproduct');


Controller

function categorywiseproduct($category_id){
	$products = product::where('category_id', $category_id)->get();
	return view('frontend.categorywiseproduct', compact('products'));
}