
এটা ডাটা Insert Table থেকে কপি করেছি ডিজাইনের বিষয়টা নিজের মত 
মেইন পরিবতন

***** productController এর

findOrFail এর মানে ভুল তথ দিলে 404 পেজে নিয়ে যাবে

   // Edit করার সময় ডাটাগুলা শো করার জনে

   function editproduct($product_id){
      $single_product_info = Product::findOrFail($product_id);
      return view('Product.productedit', compact('single_product_info'));
   }


 // Edit করার সময় ডাটাগুলা শো করার জনে Route

Route::get('/edit/product/{product_id}','ProductController@editproduct');


========================================================================================================= 
এখানে মেইন পরিবতন ফরমের মধে value="{{ $single_product_info-> Product_Name }}" এটা যুকত হবে

$single_product_info এটা Controller এর Compact থেকে আর Product_Name এটা টেবিলের কলামের নাম





@extends('layouts.app')
@section('content')

<div class="container">
   <div class="row">
      <div class="col-lg-6 offset-3">
         <div class="card px-3 py-3">
            <div class="card-header bg-success">
               Edit Product Form
               <!-- {{ $single_product_info }} -->
            </div>
            <!-- এর মাধমে success alert টা পাবো -->
            @if(session('status')) 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-success">
               {{ session('status') }}
            </div>
            @endif
            <form action="{{ url('/edit/product/insert') }}" method="post">
               <!--  {{ url('/add/product/insert') }} এটা Route থেকে আসছে -->
               <!-- ফরমের ডাটা ডাটাবেসে পাঠাইতে হলে @csrf লিখতেই হবে  -->
               @csrf
               <div class="form-group">
                  <label>Product Name</label>
                  <input type="text" class="form-control" name="Product_Name_josim" placeholder="Enter Product Name" value="{{ $single_product_info->	Product_Name }}">
               </div>
               <div class="form-group">
                  <label>Product Description</label>
                  <textarea class="form-control" name="Product_Description" rows="3" placeholder="Enter Product Description">{{ $single_product_info-> Product_Description }}</textarea>
               </div>
               <div class="form-group">
                  <label>Product Price</label>
                  <input type="text" class="form-control" name="Product_Price" placeholder="Enter Product Price" value="{{ $single_product_info-> Product_Price }}">
               </div>
               <div class="form-group">
                  <label>Product Quentity</label>
                  <input type="text" class="form-control" name="Product_Quentity" placeholder="Enter Product Quentity" value="{{ $single_product_info-> Product_Quentity }}">
               </div>
               <div class="form-group">
                  <label>Product Alert Quentity</label>
                  <input type="text" class="form-control" name="Product_Alert_Quentity" placeholder="Enter Product Alert Quentity" value="{{ $single_product_info->	Product_Alert_Quentity }}">
               </div>
               <button type="submit" class="btn btn-success">Update</button>
            </form>
         </div>
      </div>
      </div>
      </div>


@endsection